# sentiment-intention-analysis
 Toolkit for sentiment analysis and intention identification in text conversations between agents and customers using zero-shot techniques.
